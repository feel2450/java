package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Reservation extends JFrame {

	private JPanel contentPane;
	private JTextField textname;
	private JTextField textid;
	private JTextField textbuy;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the frame.
	 */
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static String tmpstr;
	static long count = 0;
	private JTextField textmovie;
	
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:reservation";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/reservation?useUnicode=yes&characterEncoding=UTF-8";
        String sql = "Select * From vation";

      		try {  
      			
                  conn = DriverManager.getConnection(url,"root","apmsetup");
                  
                  stmt = conn.createStatement( );     
                  
                  rs = stmt.executeQuery(sql);  
                  
                  System.out.println("�����ͺ��̽� ���� ����!");    
                  
              }
              catch(Exception e) {
                  System.out.println("�����ͺ��̽� ���� ����!");
              }
      	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			
			rs = stmt.executeQuery(sql);
			
		} 
		else {
			
			stmt.executeUpdate(sql);
			
		}
	}

	
	public Reservation() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 407, 384);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("- \uC608\uB9E4\uD558\uAE30 -");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel.setBounds(65, 30, 272, 54);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("\uC774\uB984  :");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1_1_1.setBounds(61, 158, 78, 15);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_4 = new JLabel("\uB9E4\uC218 :");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_4.setBounds(61, 242, 74, 15);
		contentPane.add(lblNewLabel_4);
		
		JButton btnNewButton = new JButton("\uC608\uC57D");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
					
		               try {
		            		dbConnect();
		                  query("insert", "insert into vation(`textid`,`textname`,`textmovie`,`textbuy`) "
		                        + "values('" + textid.getText() + "','" + textname.getText() + "','" + textmovie.getText() + "','" + textbuy.getText() + "')");

		                           

		                        } catch (Exception e1) {

		                           e1.printStackTrace();

		                        }
		                        System.out.println("���� �Ϸ�!");
		                        textid.setText(" ");
		                        textname.setText(" ");
		                        textmovie.setText(" ");
		                        textbuy.setText(" ");                      			
			}
		}});
		btnNewButton.setBounds(163, 293, 81, 42);
		contentPane.add(btnNewButton);
		
		textname = new JTextField();
		textname.setColumns(10);
		textname.setBounds(138, 155, 141, 21);
		contentPane.add(textname);
		
		JLabel lblNewLabel_1_1_1_2 = new JLabel("\uC544\uC774\uB514  :");
		lblNewLabel_1_1_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1_2.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1_1_1_2.setBounds(64, 114, 78, 15);
		contentPane.add(lblNewLabel_1_1_1_2);
		
		textid = new JTextField();
		textid.setColumns(10);
		textid.setBounds(138, 111, 141, 21);
		contentPane.add(textid);
		
		textbuy = new JTextField();
		textbuy.setColumns(10);
		textbuy.setBounds(138, 239, 141, 21);
		contentPane.add(textbuy);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("\uC601\uD654  :");
		lblNewLabel_1_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1_1_1_1.setBounds(57, 201, 78, 15);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		textmovie = new JTextField();
		textmovie.setColumns(10);
		textmovie.setBounds(138, 198, 141, 21);
		contentPane.add(textmovie);
	}
}
