package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class MemberUpdate extends JFrame {

	private JPanel contentPane;
	private JTextField tid;
	private JTextField tna;
	private JTextField tpw;
	private JTextField tbi;
	private JTextField tnu;
	private JTextField tma;
	
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static String tmpstr;
	static long count = 0;
	
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:movie";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/movie?useUnicode=yes&characterEncoding=UTF-8";
        String sql = "Select * From member";

      		try {  
      			
                  conn = DriverManager.getConnection(url,"root","apmsetup");
                  
                  stmt = conn.createStatement( );     
                  
                  rs = stmt.executeQuery(sql);  
                  
                  System.out.println("�����ͺ��̽� ���� ����!");    
                  
              }
              catch(Exception e) {
                  System.out.println("�����ͺ��̽� ���� ����!");
              }
      	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			
			rs = stmt.executeQuery(sql);
			
		} 
		else {
			
			stmt.executeUpdate(sql);
			
		}
	}


	public MemberUpdate() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 473, 481);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel_3 = new JLabel("- \uD68C\uC6D0 \uC815\uBCF4 \uC218\uC815 -");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel_3.setBounds(143, 10, 189, 38);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_1 = new JLabel("\uC544\uC774\uB514 :");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(110, 79, 57, 15);
		contentPane.add(lblNewLabel_1);
		
		tid = new JTextField();
		tid.setColumns(10);
		tid.setBounds(191, 76, 141, 21);
		contentPane.add(tid);
		
		JLabel lblNewLabel = new JLabel("\uC774\uB984 :");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel.setBounds(110, 129, 57, 15);
		contentPane.add(lblNewLabel);
		
		tna = new JTextField();
		tna.setColumns(10);
		tna.setBounds(192, 126, 141, 21);
		contentPane.add(tna);
		
		JLabel lblNewLabel_2 = new JLabel("\uBE44\uBC00\uBC88\uD638 :");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_2.setBounds(110, 172, 69, 15);
		contentPane.add(lblNewLabel_2);
		
		tpw = new JTextField();
		tpw.setColumns(10);
		tpw.setBounds(191, 169, 141, 21);
		contentPane.add(tpw);
		
		JLabel lblNewLabel_4 = new JLabel("\uC0DD\uB144\uC6D4\uC77C :");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_4.setBounds(110, 219, 69, 15);
		contentPane.add(lblNewLabel_4);
		
		tbi = new JTextField();
		tbi.setColumns(10);
		tbi.setBounds(191, 216, 141, 21);
		contentPane.add(tbi);
		
		JLabel lblNewLabel_5 = new JLabel("\uD734\uB300\uD3F0 \uBC88\uD638 :");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_5.setBounds(97, 266, 84, 15);
		contentPane.add(lblNewLabel_5);
		
		tnu = new JTextField();
		tnu.setColumns(10);
		tnu.setBounds(191, 263, 141, 21);
		contentPane.add(tnu);
		
		JLabel lblNewLabel_5_1 = new JLabel("\uC774\uBA54\uC77C :");
		lblNewLabel_5_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_5_1.setBounds(97, 316, 84, 15);
		contentPane.add(lblNewLabel_5_1);
		
		tma = new JTextField();
		tma.setColumns(10);
		tma.setBounds(191, 313, 141, 21);
		contentPane.add(tma);
		
		JButton btnNewButton = new JButton("\uC218\uC815");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dbConnect();
				String sql = "update member set id = '"+tid.getText()+"', name = '"+tna.getText()+"', password='"+tpw.getText()+"',dataofbirth='"+tbi.getText()+"',phone='"+tnu.getText()+"', email = '"+tma.getText()+"' where id = '"+tid.getText()+"'";
				
				try {
					stmt.executeUpdate(sql);
					System.out.println("�����ͺ��̽� �����Ϸ�");
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(192, 383, 81, 42);
		contentPane.add(btnNewButton);
	}
}
