package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Movie extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JButton btnNewButton;

	DefaultTableModel model;

	public Movie() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 602, 409);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(23, 88, 545, 260);
		contentPane.add(scrollPane);
		
		Object contents[][] = new Object[0][5];
		String header[] = {"��ȭ��ȣ", "��ȭ�̸�", "�󿵽ð�", "�帣", "�󿵳�¥"};
		model = new DefaultTableModel(contents, header);
		
		table = new JTable(model);
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel_3 = new JLabel("- \uC0C1\uC601\uC911\uC778 \uC601\uD654 -");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel_3.setBounds(33, 27, 183, 38);
		contentPane.add(lblNewLabel_3);
		
		btnNewButton = new JButton("\uC870\uD68C");
		btnNewButton.addActionListener(new ActionListener() {
			private String db_txtnu;
			private String db_txtna;
			private String db_txttime;
			private String db_txtmode;
			private String db_txtdate;
			
			public void actionPerformed(ActionEvent arg0) {
				model.setNumRows(0);
				Moviecome.dbConnect();
				try {
					
					Moviecome.query("select", "select * from movieregistration");
					while(Moviecome.rs.next()) {
						
						db_txtnu = Moviecome.rs.getString("txtnu");
						db_txtna = Moviecome.rs.getString("txtna");
						db_txttime = Moviecome.rs.getString("txttime");
						db_txtmode = Moviecome.rs.getString("txtmode");
						db_txtdate = Moviecome.rs.getString("txtdate");
				
						Object data[] = {db_txtnu, db_txtna, db_txttime, db_txtmode, db_txtdate};
						model.addRow(data);
						}
					} catch(Exception e1) {
						e1.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("����", Font.BOLD, 20));
		btnNewButton.setBounds(452, 23, 96, 42);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uC608\uB9E4");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Reservation().setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.BOLD, 20));
		btnNewButton_1.setBounds(344, 23, 96, 42);
		contentPane.add(btnNewButton_1);
	}
}
