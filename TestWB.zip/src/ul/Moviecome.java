package ul;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Moviecome extends JFrame {

	private JPanel contentPane;
	private JTextField txtnu;
	private JTextField txtna;
	private JTextField txttime;
	private JTextField txtmode;
	private JTextField txtdate;
	
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static String tmpstr;
	static long count = 0;
	
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:moviein";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/moviein?useUnicode=yes&characterEncoding=UTF-8";
        String sql = "Select * From movieregistration";

      		try {  
      			
                  conn = DriverManager.getConnection(url,"root","apmsetup");
                  
                  stmt = conn.createStatement( );     
                  
                  rs = stmt.executeQuery(sql);  
                  
                  System.out.println("�����ͺ��̽� ���� ����!");    
                  
              }
              catch(Exception e) {
                  System.out.println("�����ͺ��̽� ���� ����!");
              }
      	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			
			rs = stmt.executeQuery(sql);
			
		} 
		else {
			
			stmt.executeUpdate(sql);
			
		}
	}


	public Moviecome() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 308, 463);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel_1 = new JLabel("\uC601\uD654 \uBC88\uD638 :");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(34, 110, 70, 15);
		contentPane.add(lblNewLabel_1);
		
		txtnu = new JTextField();
		txtnu.setColumns(10);
		txtnu.setBounds(128, 107, 141, 21);
		contentPane.add(txtnu);
		
		JLabel lblNewLabel = new JLabel("\uC601\uD654 \uC81C\uBAA9 :");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel.setBounds(34, 146, 70, 15);
		contentPane.add(lblNewLabel);
		
		txtna = new JTextField();
		txtna.setColumns(10);
		txtna.setBounds(128, 143, 141, 21);
		contentPane.add(txtna);
		
		JLabel lblNewLabel_2 = new JLabel("\uC0C1\uC601 \uC2DC\uAC04 :");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_2.setBounds(34, 187, 69, 15);
		contentPane.add(lblNewLabel_2);
		
		txttime = new JTextField();
		txttime.setColumns(10);
		txttime.setBounds(128, 184, 141, 21);
		contentPane.add(txttime);
		
		JLabel lblNewLabel_4 = new JLabel("\uC601\uD654 \uC7A5\uB974 :");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_4.setBounds(35, 232, 69, 15);
		contentPane.add(lblNewLabel_4);
		
		txtmode = new JTextField();
		txtmode.setColumns(10);
		txtmode.setBounds(128, 229, 141, 21);
		contentPane.add(txtmode);
		
		JLabel lblNewLabel_5 = new JLabel("\uC601\uD654 \uAC1C\uBD09\uC77C :");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_5.setBounds(31, 275, 84, 15);
		contentPane.add(lblNewLabel_5);
		
		txtdate = new JTextField();
		txtdate.setColumns(10);
		txtdate.setBounds(128, 272, 141, 21);
		contentPane.add(txtdate);
		
		JButton btnNewButton = new JButton("\uB4F1\uB85D");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
					
		               try {
		            		dbConnect();
//		            				query("insert", "insert into movieregistration(`txtnu`,`txtna`,`txttime`,`txtmode`,`txtdate`) "
		            				query("insert", "insert into movieregistration "
		                        + "values('" + txtnu.getText() + "','" + txtna.getText() + "','" + txttime.getText() + "','" + txtmode.getText() + "','" + txtdate.getText() + "')");

		                           

		                        } catch (Exception e1) {

		                           e1.printStackTrace();

		                        }
		                        System.out.println("��ȭ ��� �Ϸ�!");
		                        txtnu.setText(" ");
		                        txtna.setText(" ");
		                        txttime.setText(" ");
		                        txtmode.setText(" ");
		                        txtdate.setText(" ");		                              
			}
		}});
		btnNewButton.setBounds(108, 334, 81, 42);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_3 = new JLabel("- \uC601\uD654 \uB4F1\uB85D -");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel_3.setBounds(62, 46, 156, 38);
		contentPane.add(lblNewLabel_3);
	}

}
