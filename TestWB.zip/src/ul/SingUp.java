package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SingUp extends JFrame {

	private JPanel contentPane;
	private JTextField email;
	private JTextField phone;
	private JTextField dataofbirth;
	private JTextField password;
	private JTextField id;
	private JTextField name;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the frame.
	 */
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static String tmpstr;
	static long count = 0;
	private JLabel lblNewLabel_3;
	
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:movie";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/movie?useUnicode=yes&characterEncoding=UTF-8";
        String sql = "Select * From member";

      		try {  
      			
                  conn = DriverManager.getConnection(url,"root","apmsetup");
                  
                  stmt = conn.createStatement( );     
                  
                  rs = stmt.executeQuery(sql);  
                  
                  System.out.println("�����ͺ��̽� ���� ����!");    
                  
              }
              catch(Exception e) {
                  System.out.println("�����ͺ��̽� ���� ����!");
              }
      	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			
			rs = stmt.executeQuery(sql);
			
		} 
		else {
			
			stmt.executeUpdate(sql);
			
		}
	}

	public SingUp() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 390, 517);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("\uD655\uC778");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
					
		               try {
		            		dbConnect();
		                  query("insert", "insert into member(`id`,`name`,`password`,`dataofbirth`,`phone`,`email`) "
		                        + "values('" + id.getText() + "','" + name.getText() + "','" + password.getText() + "','" + dataofbirth.getText() + "','" + phone.getText() + "','" + email.getText() + "')");

		                           

		                        } catch (Exception e1) {

		                           e1.printStackTrace();

		                        }
		                        System.out.println("���׸��߰�");
		                        id.setText(" ");
		                        name.setText(" ");
		                        password.setText(" ");
		                        dataofbirth.setText(" ");
		                        phone.setText(" ");
		                        email.setText(" ");	                       
			}
		}});
		btnNewButton.setBounds(143, 394, 81, 42);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_5_1 = new JLabel("\uC774\uBA54\uC77C :");
		lblNewLabel_5_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_5_1.setBounds(48, 327, 84, 15);
		contentPane.add(lblNewLabel_5_1);
		
		email = new JTextField();
		email.setColumns(10);
		email.setBounds(142, 324, 141, 21);
		contentPane.add(email);
		
		JLabel lblNewLabel_5 = new JLabel("\uD734\uB300\uD3F0 \uBC88\uD638 :");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_5.setBounds(48, 277, 84, 15);
		contentPane.add(lblNewLabel_5);
		
		phone = new JTextField();
		phone.setColumns(10);
		phone.setBounds(142, 274, 141, 21);
		contentPane.add(phone);
		
		JLabel lblNewLabel_4 = new JLabel("\uC0DD\uB144\uC6D4\uC77C :");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_4.setBounds(61, 230, 69, 15);
		contentPane.add(lblNewLabel_4);
		
		dataofbirth = new JTextField();
		dataofbirth.setColumns(10);
		dataofbirth.setBounds(142, 227, 141, 21);
		contentPane.add(dataofbirth);
		
		JLabel lblNewLabel_2 = new JLabel("\uBE44\uBC00\uBC88\uD638 :");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_2.setBounds(61, 183, 69, 15);
		contentPane.add(lblNewLabel_2);
		
		password = new JTextField();
		password.setColumns(10);
		password.setBounds(142, 180, 141, 21);
		contentPane.add(password);
		
		JLabel lblNewLabel_1 = new JLabel("\uC544\uC774\uB514 :");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(61, 90, 57, 15);
		contentPane.add(lblNewLabel_1);
		
		id = new JTextField();
		id.setColumns(10);
		id.setBounds(142, 87, 141, 21);
		contentPane.add(id);
		
		JLabel lblNewLabel = new JLabel("\uC774\uB984 :");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel.setBounds(61, 140, 57, 15);
		contentPane.add(lblNewLabel);
		
		name = new JTextField();
		name.setColumns(10);
		name.setBounds(143, 137, 141, 21);
		contentPane.add(name);
		
		lblNewLabel_3 = new JLabel("- \uD68C\uC6D0\uAC00\uC785 -");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel_3.setBounds(126, 21, 124, 38);
		contentPane.add(lblNewLabel_3);
	}
}
