package ul;

import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Memberinquiry extends JFrame {

	private JPanel contentPane;
	private JTable table;
	
    DefaultTableModel model;
	
	public Memberinquiry() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 526, 381);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("- \uD68C\uC6D0 \uC815\uBCF4 \uC870\uD68C -");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel.setBounds(59, 26, 224, 34);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(59, 107, 382, 189);
		contentPane.add(scrollPane);
		
		Object contents[][] = new Object[0][3];
		String header[] = {"NAME", "ID", "PHONE"};
		model = new DefaultTableModel(contents, header);
		
		table = new JTable(model);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("\uC870\uD68C");
		btnNewButton.addActionListener(new ActionListener() {
			private String db_name;
			private String db_id;
			private String db_phone;

			public void actionPerformed(ActionEvent arg0) {
				model.setNumRows(0);
				SingUp.dbConnect();
				try {
					
					SingUp.query("select", "select * from member");
					while(SingUp.rs.next()) {
						
						db_name = SingUp.rs.getString("name");
						db_id = SingUp.rs.getString("id");
						db_phone = SingUp.rs.getString("phone");
				
						Object data[] = {db_name, db_id, db_phone};
						model.addRow(data);
						}
					} catch(Exception e1) {
						e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setFont(new Font("����", Font.BOLD, 20));
		btnNewButton.setBounds(393, 34, 81, 42);
		contentPane.add(btnNewButton);
	}
}



















