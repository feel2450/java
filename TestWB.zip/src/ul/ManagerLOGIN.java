package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class ManagerLOGIN extends JFrame {

	private JPanel contentPane;
	private JTextField idid;
	private JPasswordField pwpw;


	public ManagerLOGIN() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel_1 = new JLabel("\uAD00\uB9AC\uC790 \uB85C\uADF8\uC778");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("���Ļ�浸��", Font.BOLD, 20));
		lblNewLabel_1.setBounds(92, 22, 246, 21);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\uC544\uC774\uB514 :");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(92, 92, 57, 15);
		contentPane.add(lblNewLabel_1_1);
		
		idid = new JTextField();
		idid.setColumns(10);
		idid.setBounds(171, 89, 141, 21);
		contentPane.add(idid);
		
		JLabel lblNewLabel_2 = new JLabel("\uBE44\uBC00\uBC88\uD638 :");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_2.setBounds(92, 136, 69, 15);
		contentPane.add(lblNewLabel_2);
		
		pwpw = new JPasswordField();
		pwpw.setBounds(171, 133, 141, 18);
		contentPane.add(pwpw);
		
		JButton btnNewButton = new JButton("\uB85C\uADF8\uC778");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				   dbmanager.dbConnect();
		            String pw = ""; 
		            char[] secret_pw = pwpw.getPassword(); 
		            
		            for(char cha : secret_pw){
		               Character.toString(cha);
		             pw += (pw.equals("")) ? ""+cha+"" : ""+cha+"";
		             }
		            try {
		               while(dbmanager.rs.next()) {
		                  if(idid.getText().equals(dbmanager.rs.getString("id")))
		                  
		                  if(pw.equals(dbmanager.rs.getString("password"))) {
		                     
		                     new Manager().setVisible(true);
		                     dispose();
		                     return;
		                  }
		               }
		            
		            JOptionPane.showMessageDialog(contentPane, "������ �߸� �Ǿ����ϴ�.");
		         }
		            catch (SQLException e1) {
		               // TODO Auto-generated catch block
		               e1.printStackTrace();
		            }         
		            dbmanager.dbDis();
			}
		});
		btnNewButton.setBounds(160, 190, 102, 42);
		contentPane.add(btnNewButton);
	}
}
