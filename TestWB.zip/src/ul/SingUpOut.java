package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SingUpOut extends JFrame {

	private JPanel contentPane;
	private JTextField idt;
	private JTextField pwt;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the frame.
	 */
	public SingUpOut() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 332, 346);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("- \uD68C\uC6D0\uD0C8\uD1F4 -");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel.setBounds(91, 21, 124, 38);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uC544\uC774\uB514 :");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(29, 108, 57, 15);
		contentPane.add(lblNewLabel_1);
		
		idt = new JTextField();
		idt.setColumns(10);
		idt.setBounds(108, 105, 141, 21);
		contentPane.add(idt);
		
		JLabel lblNewLabel_2 = new JLabel("\uBE44\uBC00\uBC88\uD638 :");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_2.setBounds(29, 174, 69, 15);
		contentPane.add(lblNewLabel_2);
		
		pwt = new JTextField();
		pwt.setColumns(10);
		pwt.setBounds(108, 171, 141, 21);
		contentPane.add(pwt);
		
		JButton btnNewButton = new JButton("\uD0C8\uD1F4 \uD655\uC778");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		         dbconnect.dbConnect();
		            
		            try {
		            	dbconnect.query("delete", "delete from member where id = " + "'" + idt.getText() + "'");
		               //viewData();
		               System.out.println("�����ͺ��̽� �����Ϸ�");
		               
		            } catch (Exception e1) {
		               e1.printStackTrace();
		            }
		            new SwingDemo().setVisible(true);
		            dispose();
		         }
		      });
		btnNewButton.setBounds(108, 255, 97, 42);
		contentPane.add(btnNewButton);
	}
}
