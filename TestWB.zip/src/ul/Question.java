package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Question extends JFrame {

	private JPanel contentPane;
	private JTextField questionwrite;
	private JTextField questiondate;
	private JTextField questionnu;
	
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static String tmpstr;
	static long count = 0;
	
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:question";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/question?useUnicode=yes&characterEncoding=UTF-8";
        String sql = "Select * From questionwrite";

      		try {  
      			
                  conn = DriverManager.getConnection(url,"root","apmsetup");
                  
                  stmt = conn.createStatement( );     
                  
                  rs = stmt.executeQuery(sql);  
                  
                  System.out.println("�����ͺ��̽� ���� ����!");    
                  
              }
              catch(Exception e) {
                  System.out.println("�����ͺ��̽� ���� ����!");
              }
      	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			
			rs = stmt.executeQuery(sql);
			
		} 
		else {
			
			stmt.executeUpdate(sql);
			
		}
	}
	
	public Question() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 328, 345);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("- \uBB38\uC758\uD558\uAE30 -");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(96, 10, 124, 38);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uBB38\uC758 \uC77C\uC790 :");
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(21, 107, 78, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uBB38\uC758 \uB0B4\uC6A9 :");
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_2.setBounds(21, 143, 78, 15);
		contentPane.add(lblNewLabel_2);
		
		questionwrite = new JTextField();
		questionwrite.setBounds(96, 143, 171, 83);
		contentPane.add(questionwrite);
		questionwrite.setColumns(10);
		
		JButton btnNewButton = new JButton("\uC811\uC218");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
					
		               try {
		            		dbConnect();
		                  query("insert", "insert into questionwrite(`questionnu`,`questiondate`,`questionwrite`) "
		                        + "values('" + questionnu.getText() + "','" + questiondate.getText() + "','" + questionwrite.getText() + "')");

		                           

		                        } catch (Exception e1) {

		                           e1.printStackTrace();

		                        }
		                        System.out.println("���� �Ϸ�");
		                        questionnu.setText(" ");
		                        questiondate.setText(" ");
		                        questionwrite.setText(" ");	                                    
				
			}
		}});
		btnNewButton.setBounds(124, 254, 81, 42);
		contentPane.add(btnNewButton);
		
		questiondate = new JTextField();
		questiondate.setColumns(10);
		questiondate.setBounds(96, 104, 141, 21);
		contentPane.add(questiondate);
		
		questionnu = new JTextField();
		questionnu.setColumns(10);
		questionnu.setBounds(96, 68, 141, 21);
		contentPane.add(questionnu);
		
		JLabel lblNewLabel_1_1 = new JLabel("\uBB38\uC758 \uBC88\uD638 :");
		lblNewLabel_1_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(21, 71, 78, 15);
		contentPane.add(lblNewLabel_1_1);
	}
}
