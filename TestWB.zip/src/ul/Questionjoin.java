package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Questionjoin extends JFrame {

	private JPanel contentPane;
	private JTable table;
	
	DefaultTableModel model;

	public Questionjoin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 629, 422);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("- \uBB38\uC758 \uB0B4\uC5ED \uC870\uD68C -");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel.setBounds(45, 27, 182, 38);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(30, 100, 548, 261);
		contentPane.add(scrollPane);
		
		Object contents[][] = new Object[0][3];
		String header[] = {"���ǹ�ȣ", "���ǳ�¥", "���ǳ���"};
		model = new DefaultTableModel(contents, header);
		
		table = new JTable(model);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("\uC870\uD68C");
		btnNewButton.addActionListener(new ActionListener() {
			private String db_questionnu;
			private String db_questiondate;
			private String db_questionwrite;

			public void actionPerformed(ActionEvent e) {
				model.setNumRows(0);
				Question.dbConnect();
				try {
					
					Question.query("select", "select * from questionwrite");
					while(Question.rs.next()) {
						
						db_questionnu = Question.rs.getString("questionnu");
						db_questiondate = Question.rs.getString("questiondate");
						db_questionwrite = Question.rs.getString("questionwrite");
				
						Object data[] = {db_questionnu, db_questiondate, db_questionwrite};
						model.addRow(data);
						}
					} catch(Exception e1) {
						e1.printStackTrace();
				}	
			}
		});
		btnNewButton.setFont(new Font("����", Font.BOLD, 20));
		btnNewButton.setBounds(473, 37, 81, 42);
		contentPane.add(btnNewButton);
	}

}
