package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SwingDemo extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the frame.
	 */
	public SwingDemo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel_1 = new JLabel("\u2605 \uC601\uD654 \uC608\uB9E4 \uC81C\uC77C \uBE60\uB978 \uACF3 \u2605 ");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("���Ļ�浸��", Font.BOLD, 20));
		lblNewLabel_1.setBounds(93, 27, 246, 21);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("\uB85C\uADF8\uC778 \uD558\uAE30");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainScreen().setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("����", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.setBounds(152, 69, 121, 48);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uD68C\uC6D0\uAC00\uC785");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new SingUp().setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1.setBounds(152, 124, 121, 48);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\uBB38\uC758\uD558\uAE30");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Question().setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("����", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_2.setBounds(152, 182, 121, 48);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_2_1 = new JButton("\uAD00\uB9AC\uC790 \uB85C\uADF8\uC778");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ManagerLOGIN().setVisible(true);
			}
		});
		btnNewButton_2_1.setFont(new Font("����", Font.BOLD | Font.ITALIC, 12));
		btnNewButton_2_1.setBounds(301, 224, 121, 27);
		contentPane.add(btnNewButton_2_1);
	}
}
