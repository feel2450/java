package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Reservation_2 extends JFrame {

	private JPanel contentPane;
	private JTable table;
	
	DefaultTableModel model;
	private JTable table_1;

	public Reservation_2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 494, 438);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("- \uC608\uB9E4 \uB0B4\uC5ED \uC870\uD68C -");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel.setBounds(100, 20, 272, 54);
		contentPane.add(lblNewLabel);
		
		Object contents[][] = new Object[0][4];
		String header[] = {"���̵�", "�̸�", "��ȭ�̸�", "�ż�"};
		model = new DefaultTableModel(contents, header);
		
		JButton btnNewButton = new JButton("\uC870\uD68C");
		btnNewButton.addActionListener(new ActionListener() {
			private String db_textid;
			private String db_textname;
			private String db_textmovie;
			private String db_textbuy;

			public void actionPerformed(ActionEvent e) {
				model.setNumRows(0);
				Reservation.dbConnect();
				try {
					
					Reservation.query("select", "select * from vation");
					while(Reservation.rs.next()) {
						
						db_textid = Reservation.rs.getString("textid");
						db_textname = Reservation.rs.getString("textname");
						db_textmovie = Reservation.rs.getString("textmovie");
						db_textbuy = Reservation.rs.getString("textbuy");
						
						Object data[] = {db_textid, db_textname, db_textmovie, db_textbuy};
						model.addRow(data);
						}
					} catch(Exception e1) {
						e1.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("����", Font.BOLD, 20));
		btnNewButton.setBounds(191, 347, 96, 42);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(24, 84, 427, 252);
		contentPane.add(scrollPane);
		
		table_1 = new JTable(model);
		scrollPane.setViewportView(table_1);
		
	}
}
