package ul;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class MainScreen extends JFrame {

	private JPanel contentPane;
	private JTextField idtext;
	private JPasswordField pwtext;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the frame.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SwingDemo frame = new SwingDemo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public MainScreen() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel_1 = new JLabel("\uD68C\uC6D0 \uB85C\uADF8\uC778");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("���Ļ�浸��", Font.BOLD, 20));
		lblNewLabel_1.setBounds(93, 27, 246, 21);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\uC544\uC774\uB514 :");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(93, 97, 57, 15);
		contentPane.add(lblNewLabel_1_1);
		
		idtext = new JTextField();
		idtext.setColumns(10);
		idtext.setBounds(172, 94, 141, 21);
		contentPane.add(idtext);
		
		JLabel lblNewLabel_2 = new JLabel("\uBE44\uBC00\uBC88\uD638 :");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_2.setBounds(93, 141, 69, 15);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("\uB85C\uADF8\uC778");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		            dbconnect.dbConnect();
		            String pw = ""; 
		            char[] secret_pw = pwtext.getPassword(); 
		            
		            for(char cha : secret_pw){
		               Character.toString(cha);
		             pw += (pw.equals("")) ? ""+cha+"" : ""+cha+"";
		             }
		            try {
		               while(dbconnect.rs.next()) {
		                  if(idtext.getText().equals(dbconnect.rs.getString("id")))
		                  
		                  if(pw.equals(dbconnect.rs.getString("password"))) {
		                     
		                     new MainLOGIN().setVisible(true);
		                     dispose();
		                     return;
		                  }
		               }
		            
		            JOptionPane.showMessageDialog(contentPane, "������ �߸� �Ǿ����ϴ�.");
		         }
		            catch (SQLException e1) {
		               // TODO Auto-generated catch block
		               e1.printStackTrace();
		            }         
		            dbconnect.dbDis();
		         }
		   });
		btnNewButton.setBounds(161, 195, 102, 42);
		contentPane.add(btnNewButton);
		
		pwtext = new JPasswordField();
		pwtext.setBounds(172, 138, 141, 18);
		contentPane.add(pwtext);
	}
}