import java.awt.EventQueue;

import ul.SwingDemo;

/**
 * 
 */

/**
 * @author user
 *
 */
public class WBtest {
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SwingDemo frame = new SwingDemo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * @param args
	 */

}